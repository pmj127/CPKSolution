(function(window, undefined) {

var jimLinks = {
"f4652a17-bfa0-40e7-8943-0804935e91fc" : {
"Button_10" : [
"26f24953-58f7-4ff2-84a3-0cf4fb413f25"
],
"Button_11" : [
"26f24953-58f7-4ff2-84a3-0cf4fb413f25"
]
},
"eb5eb0af-19bf-4c60-972b-fcfa0ea05e32" : {
"Button_1" : [
"6f7a217f-ae6c-4eb2-a1c7-d61b52dd5800"
],
"Button_2" : [
"6f7a217f-ae6c-4eb2-a1c7-d61b52dd5800"
]
},
"9ebd72c4-7159-4cfd-826b-6fcf82300da4" : {
"Text_cell_5" : [
"9ebd72c4-7159-4cfd-826b-6fcf82300da4"
],
"Text_cell_6" : [
"f486c4aa-7209-4fcf-9bc8-3dedba101181"
],
"Text_cell_11" : [
"f486c4aa-7209-4fcf-9bc8-3dedba101181"
],
"Text_cell_17" : [
"f486c4aa-7209-4fcf-9bc8-3dedba101181"
],
"Text_cell_14" : [
"f486c4aa-7209-4fcf-9bc8-3dedba101181"
]
},
"88221d3a-91af-46a0-9886-e77414066779" : {
"Text_cell_5" : [
"1e237071-5daf-4e28-91d6-6b08a1edae72"
],
"Text_cell_6" : [
"1e237071-5daf-4e28-91d6-6b08a1edae72"
],
"Text_cell_11" : [
"1e237071-5daf-4e28-91d6-6b08a1edae72"
],
"Text_cell_17" : [
"1e237071-5daf-4e28-91d6-6b08a1edae72"
],
"Text_cell_14" : [
"1e237071-5daf-4e28-91d6-6b08a1edae72"
]
},
"2b544a2f-621a-49c8-b596-613dbd43a9fd" : {
"Button_1" : [
"26f24953-58f7-4ff2-84a3-0cf4fb413f25"
],
"Button_2" : [
"26f24953-58f7-4ff2-84a3-0cf4fb413f25"
]
},
"26f24953-58f7-4ff2-84a3-0cf4fb413f25" : {
"Text_cell_5" : [
"1e237071-5daf-4e28-91d6-6b08a1edae72"
],
"Text_cell_6" : [
"1e237071-5daf-4e28-91d6-6b08a1edae72"
],
"Text_cell_11" : [
"1e237071-5daf-4e28-91d6-6b08a1edae72"
],
"Button_1" : [
"f4652a17-bfa0-40e7-8943-0804935e91fc"
],
"Button_2" : [
"fea2d2d7-3b02-4286-a598-bc46b94a5407"
],
"Text_cell_30" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Text_cell_31" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Text_cell_32" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Text_cell_33" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Text_cell_34" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Button_4" : [
"2b544a2f-621a-49c8-b596-613dbd43a9fd"
],
"Button_7" : [
"f4652a17-bfa0-40e7-8943-0804935e91fc"
]
},
"d12245cc-1680-458d-89dd-4f0d7fb22724" : {
"Menu_item_3" : [
"e992888e-b493-4b1c-9f31-9f859aecf46d"
],
"Menu_item_4" : [
"9ebd72c4-7159-4cfd-826b-6fcf82300da4"
],
"Menu_item_5" : [
"26f24953-58f7-4ff2-84a3-0cf4fb413f25"
],
"Menu_item_1" : [
"88221d3a-91af-46a0-9886-e77414066779"
],
"Button_1" : [
"6f7a217f-ae6c-4eb2-a1c7-d61b52dd5800"
],
"Button_2" : [
"999e5773-9419-4962-919c-1bf13e528c3d"
],
"Button_3" : [
"7c45a4ef-66eb-4694-ab7e-e02abd227063"
]
},
"57df3d41-3e3f-48c7-b7f4-54647c30234c" : {
"Button_10" : [
"e992888e-b493-4b1c-9f31-9f859aecf46d"
],
"Button_11" : [
"e992888e-b493-4b1c-9f31-9f859aecf46d"
]
},
"1e237071-5daf-4e28-91d6-6b08a1edae72" : {
"Button_1" : [
"88221d3a-91af-46a0-9886-e77414066779"
]
},
"6f7a217f-ae6c-4eb2-a1c7-d61b52dd5800" : {
"Text_cell_5" : [
"eb5eb0af-19bf-4c60-972b-fcfa0ea05e32"
],
"Text_cell_6" : [
"eb5eb0af-19bf-4c60-972b-fcfa0ea05e32"
],
"Text_cell_11" : [
"eb5eb0af-19bf-4c60-972b-fcfa0ea05e32"
],
"Button_1" : [
"eb5eb0af-19bf-4c60-972b-fcfa0ea05e32"
]
},
"fea2d2d7-3b02-4286-a598-bc46b94a5407" : {
"Button_1" : [
"26f24953-58f7-4ff2-84a3-0cf4fb413f25"
],
"Button_2" : [
"26f24953-58f7-4ff2-84a3-0cf4fb413f25"
]
},
"e992888e-b493-4b1c-9f31-9f859aecf46d" : {
"Text_cell_5" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Text_cell_6" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Text_cell_11" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Text_cell_14" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
],
"Text_cell_17" : [
"57df3d41-3e3f-48c7-b7f4-54647c30234c"
]
},
"7c45a4ef-66eb-4694-ab7e-e02abd227063" : {
"Button_10" : [
"88221d3a-91af-46a0-9886-e77414066779"
],
"Button_11" : [
"88221d3a-91af-46a0-9886-e77414066779"
]
}    
}

window.jimLinks = jimLinks;
})(window);