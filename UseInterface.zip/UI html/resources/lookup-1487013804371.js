(function(window, undefined) {
var dictionary = {
"f4652a17-bfa0-40e7-8943-0804935e91fc": "Add Child Group",
"eb5eb0af-19bf-4c60-972b-fcfa0ea05e32": "Send Message",
"9ebd72c4-7159-4cfd-826b-6fcf82300da4": "Upload Report List",
"88221d3a-91af-46a0-9886-e77414066779": "Reports List",
"2b544a2f-621a-49c8-b596-613dbd43a9fd": "Add User",
"26f24953-58f7-4ff2-84a3-0cf4fb413f25": "Manage Group",
"d12245cc-1680-458d-89dd-4f0d7fb22724": "CPKSolution_Main",
"57df3d41-3e3f-48c7-b7f4-54647c30234c": "User Info",
"1e237071-5daf-4e28-91d6-6b08a1edae72": "Reports Viewer",
"6f7a217f-ae6c-4eb2-a1c7-d61b52dd5800": "Message List",
"999e5773-9419-4962-919c-1bf13e528c3d": "Sign in",
"f486c4aa-7209-4fcf-9bc8-3dedba101181": "Upload Reports",
"fea2d2d7-3b02-4286-a598-bc46b94a5407": "Add Report",
"e992888e-b493-4b1c-9f31-9f859aecf46d": "Manage User",
"7c45a4ef-66eb-4694-ab7e-e02abd227063": "Register",
"87db3cf7-6bd4-40c3-b29c-45680fb11462": "960 grid - 16 columns",
"e5f958a4-53ae-426e-8c05-2f7d8e00b762": "960 grid - 12 columns",
"f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
"bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
};

var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
window.lookUpURL = function(fragment) {
var matches = uriRE.exec(fragment || "") || [],
folder = matches[2] || "",
canvas = matches[3] || "",
name, url;
if(dictionary.hasOwnProperty(canvas)) { /* search by name */
url = folder + "/" + canvas;
}
return url;
};

window.lookUpName = function(fragment) {
var matches = uriRE.exec(fragment || "") || [],
folder = matches[2] || "",
canvas = matches[3] || "",
name, canvasName;
if(dictionary.hasOwnProperty(canvas)) { /* search by name */
canvasName = dictionary[canvas];
}
return canvasName;
};
})(window);